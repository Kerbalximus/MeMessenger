# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MeMessengerUi/memessenger_setting.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1280, 720)
        MainWindow.setStyleSheet("background-color: #305459; color: #fff")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.setting_button = QtWidgets.QPushButton(self.centralwidget)
        self.setting_button.setGeometry(QtCore.QRect(220, 10, 60, 60))
        font = QtGui.QFont()
        font.setFamily("Cantarell Light")
        self.setting_button.setFont(font)
        self.setting_button.setStyleSheet("QPushButton {\n"
"    border-radius: 30px ;\n"
"    background: #2c8591;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #347f6e\n"
"}")
        self.setting_button.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("data/setting_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setting_button.setIcon(icon)
        self.setting_button.setIconSize(QtCore.QSize(32, 32))
        self.setting_button.setObjectName("setting_button")
        self.setting_list = QtWidgets.QListWidget(self.centralwidget)
        self.setting_list.setGeometry(QtCore.QRect(20, 80, 1241, 611))
        self.setting_list.setStyleSheet("border: 0px solid #fff")
        self.setting_list.setObjectName("setting_list")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MeMessenger Alpha"))
