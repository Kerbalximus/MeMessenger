# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MeMessengerUi/memessenger.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1280, 720)
        MainWindow.setMaximumSize(QtCore.QSize(1280, 800))
        font = QtGui.QFont()
        font.setFamily("Arial")
        MainWindow.setFont(font)
        MainWindow.setFocusPolicy(QtCore.Qt.ClickFocus)
        MainWindow.setWindowOpacity(11.0)
        MainWindow.setStyleSheet("background-color: #305459; color: #fff")
        MainWindow.setLocale(QtCore.QLocale(QtCore.QLocale.Russian, QtCore.QLocale.Russia))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.main_page = QtWidgets.QPushButton(self.centralwidget)
        self.main_page.setGeometry(QtCore.QRect(10, 10, 60, 60))
        self.main_page.setStyleSheet("QPushButton {\n"
"    border-radius: 30px ;\n"
"    background: #2c8591;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #347f6e\n"
"}")
        self.main_page.setText("")
        self.main_page.setObjectName("main_page")
        self.post_page = QtWidgets.QPushButton(self.centralwidget)
        self.post_page.setGeometry(QtCore.QRect(80, 10, 60, 60))
        self.post_page.setStyleSheet("QPushButton {\n"
"    border-radius: 30px ;\n"
"    background: #2c8591;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #347f6e\n"
"}")
        self.post_page.setText("")
        self.post_page.setObjectName("post_page")
        self.channel_page = QtWidgets.QPushButton(self.centralwidget)
        self.channel_page.setGeometry(QtCore.QRect(150, 10, 60, 60))
        self.channel_page.setStyleSheet("QPushButton {\n"
"    border-radius: 30px ;\n"
"    background: #2c8591;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #347f6e\n"
"}")
        self.channel_page.setText("")
        self.channel_page.setObjectName("channel_page")
        self.user_info = QtWidgets.QWidget(self.centralwidget)
        self.user_info.setGeometry(QtCore.QRect(1000, 630, 271, 80))
        self.user_info.setStyleSheet("background: #2c8591;border-radius: 20px")
        self.user_info.setObjectName("user_info")
        self.user_avatar = QtWidgets.QLabel(self.user_info)
        self.user_avatar.setGeometry(QtCore.QRect(10, 10, 64, 64))
        self.user_avatar.setStyleSheet("border-radius: 32px;background: #2c8591;")
        self.user_avatar.setText("")
        self.user_avatar.setObjectName("user_avatar")
        self.user_name = QtWidgets.QLabel(self.user_info)
        self.user_name.setGeometry(QtCore.QRect(80, 20, 161, 21))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.user_name.setFont(font)
        self.user_name.setStyleSheet("color: #e9f7f1")
        self.user_name.setObjectName("user_name")
        self.user_email = QtWidgets.QLabel(self.user_info)
        self.user_email.setGeometry(QtCore.QRect(80, 50, 191, 19))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.user_email.setFont(font)
        self.user_email.setStyleSheet("color: #a4bdb2")
        self.user_email.setObjectName("user_email")
        self.send_message_widget = QtWidgets.QWidget(self.centralwidget)
        self.send_message_widget.setGeometry(QtCore.QRect(210, 660, 781, 41))
        self.send_message_widget.setObjectName("send_message_widget")
        self.send_message_button = QtWidgets.QPushButton(self.send_message_widget)
        self.send_message_button.setGeometry(QtCore.QRect(740, 0, 40, 40))
        self.send_message_button.setStyleSheet("QPushButton {\n"
"    border-radius: 20px ;\n"
"    background-color: #2c8591;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #347f6e\n"
"}")
        self.send_message_button.setObjectName("send_message_button")
        self.text_message = QtWidgets.QLineEdit(self.send_message_widget)
        self.text_message.setGeometry(QtCore.QRect(80, 0, 651, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.text_message.setFont(font)
        self.text_message.setStyleSheet("border-radius: 10px ;\n"
"background: #2c8591;")
        self.text_message.setObjectName("text_message")
        self.message_list = QtWidgets.QListWidget(self.centralwidget)
        self.message_list.setGeometry(QtCore.QRect(290, 80, 701, 571))
        self.message_list.setObjectName("message_list")
        self.find_friend_line = QtWidgets.QLineEdit(self.centralwidget)
        self.find_friend_line.setGeometry(QtCore.QRect(1000, 10, 271, 60))
        font = QtGui.QFont()
        font.setFamily("Arial Black")
        self.find_friend_line.setFont(font)
        self.find_friend_line.setStyleSheet("background: #2c8591;border-radius: 20px")
        self.find_friend_line.setObjectName("find_friend_line")
        self.error_label = QtWidgets.QLabel(self.centralwidget)
        self.error_label.setGeometry(QtCore.QRect(290, 20, 691, 41))
        self.error_label.setText("")
        self.error_label.setAlignment(QtCore.Qt.AlignCenter)
        self.error_label.setObjectName("error_label")
        self.users_chat = QtWidgets.QListWidget(self.centralwidget)
        self.users_chat.setGeometry(QtCore.QRect(1000, 90, 271, 531))
        self.users_chat.setStyleSheet("background: #2c8591;border-radius: 20px")
        self.users_chat.setObjectName("users_chat")
        self.chats_list = QtWidgets.QListWidget(self.centralwidget)
        self.chats_list.setGeometry(QtCore.QRect(10, 80, 271, 620))
        self.chats_list.setStyleSheet("background: #2c8591;")
        self.chats_list.setObjectName("chats_list")
        self.setting_button = QtWidgets.QPushButton(self.centralwidget)
        self.setting_button.setGeometry(QtCore.QRect(220, 10, 60, 60))
        font = QtGui.QFont()
        font.setFamily("Cantarell Light")
        self.setting_button.setFont(font)
        self.setting_button.setStyleSheet("QPushButton {\n"
"    border-radius: 30px ;\n"
"    background: #2c8591;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #347f6e\n"
"}")
        self.setting_button.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("data/setting_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setting_button.setIcon(icon)
        self.setting_button.setIconSize(QtCore.QSize(32, 32))
        self.setting_button.setObjectName("setting_button")
        self.load_message = QtWidgets.QLabel(self.centralwidget)
        self.load_message.setGeometry(QtCore.QRect(290, 80, 711, 571))
        self.load_message.setText("")
        self.load_message.setAlignment(QtCore.Qt.AlignCenter)
        self.load_message.setObjectName("load_message")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MeMessenger alpha", "ddd"))
        self.send_message_button.setText(_translate("MainWindow", "➤"))
        self.text_message.setPlaceholderText(_translate("MainWindow", "Выберите кому написать)"))
        self.find_friend_line.setPlaceholderText(_translate("MainWindow", "Найти друга..."))
