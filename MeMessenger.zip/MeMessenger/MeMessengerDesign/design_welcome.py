# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MeMessengerUi/memessenger_welcome.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1280, 720)
        MainWindow.setStyleSheet("background: #d7d7ff")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.background = QtWidgets.QLabel(self.centralwidget)
        self.background.setGeometry(QtCore.QRect(0, 0, 1280, 720))
        self.background.setStyleSheet("")
        self.background.setText("")
        self.background.setScaledContents(True)
        self.background.setAlignment(QtCore.Qt.AlignCenter)
        self.background.setObjectName("background")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(480, 60, 300, 270))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("data/birthday.png"))
        self.label.setScaledContents(True)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(430, 330, 420, 110))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.label_2.setFont(font)
        self.label_2.setScaledContents(False)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setWordWrap(True)
        self.label_2.setObjectName("label_2")
        self.day_button = QtWidgets.QPushButton(self.centralwidget)
        self.day_button.setGeometry(QtCore.QRect(460, 450, 88, 27))
        self.day_button.setStyleSheet("QPushButton {\n"
"        background: #fff;\n"
"        border: 3px solid #aaa;\n"
"        border-radius: 10px\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background: #ebebeb;\n"
"}\n"
"")
        self.day_button.setText("")
        self.day_button.setObjectName("day_button")
        self.month_button = QtWidgets.QPushButton(self.centralwidget)
        self.month_button.setGeometry(QtCore.QRect(580, 450, 88, 27))
        self.month_button.setStyleSheet("QPushButton {\n"
"        background: #fff;\n"
"        border: 3px solid #aaa;\n"
"        border-radius: 10px\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background: #ebebeb;\n"
"}\n"
"")
        self.month_button.setText("")
        self.month_button.setObjectName("month_button")
        self.year_button = QtWidgets.QPushButton(self.centralwidget)
        self.year_button.setGeometry(QtCore.QRect(710, 450, 88, 27))
        self.year_button.setStyleSheet("QPushButton {\n"
"        background: #fff;\n"
"        border: 3px solid #aaa;\n"
"        border-radius: 10px\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background: #ebebeb;\n"
"}\n"
"")
        self.year_button.setText("")
        self.year_button.setObjectName("year_button")
        self.day_list_widget = QtWidgets.QListWidget(self.centralwidget)
        self.day_list_widget.setGeometry(QtCore.QRect(460, 480, 91, 211))
        self.day_list_widget.setStyleSheet("QListWidget {\n"
"        background: #fff;\n"
"        border: 3px solid #aaa;\n"
"        border-radius: 10px\n"
"}\n"
"\n"
"QListWidgetElement:hover {\n"
"    background: #ebebeb;\n"
"}")
        self.day_list_widget.setWordWrap(True)
        self.day_list_widget.setObjectName("day_list_widget")
        self.month_list_widget = QtWidgets.QListWidget(self.centralwidget)
        self.month_list_widget.setGeometry(QtCore.QRect(580, 480, 91, 211))
        self.month_list_widget.setStyleSheet("QListWidget {\n"
"        background: #fff;\n"
"        border: 3px solid #aaa;\n"
"        border-radius: 10px\n"
"}\n"
"\n"
"QListWidgetElement:hover {\n"
"    background: #ebebeb;\n"
"}")
        self.month_list_widget.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.month_list_widget.setWordWrap(True)
        self.month_list_widget.setObjectName("month_list_widget")
        self.year_list_widget = QtWidgets.QListWidget(self.centralwidget)
        self.year_list_widget.setGeometry(QtCore.QRect(710, 480, 91, 211))
        self.year_list_widget.setStyleSheet("QListWidget {\n"
"        background: #fff;\n"
"        border: 3px solid #aaa;\n"
"        border-radius: 10px\n"
"}\n"
"\n"
"QListWidgetElement:hover {\n"
"    background: #ebebeb;\n"
"}")
        self.year_list_widget.setWordWrap(True)
        self.year_list_widget.setObjectName("year_list_widget")
        self.next_button = QtWidgets.QPushButton(self.centralwidget)
        self.next_button.setGeometry(QtCore.QRect(457, 626, 341, 51))
        self.next_button.setStyleSheet("background-color: #2ba3d6;\n"
"border-radius: 10px;\n"
"color: #fff;")
        self.next_button.setObjectName("next_button")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(470, 430, 67, 19))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.label_3.setFont(font)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(590, 430, 67, 19))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.label_4.setFont(font)
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(720, 430, 67, 19))
        self.label_5.setAlignment(QtCore.Qt.AlignCenter)
        self.label_5.setObjectName("label_5")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "Чтобы фильтровать контент, установить стиль общения и т.д. Нам нужно знать когда вы родились.                                              P.S. Ну и конечно для бонусов на ваш день рождения"))
        self.next_button.setText(_translate("MainWindow", "Далее"))
        self.label_3.setText(_translate("MainWindow", "День"))
        self.label_4.setText(_translate("MainWindow", "Месяц"))
        self.label_5.setText(_translate("MainWindow", "Год"))
