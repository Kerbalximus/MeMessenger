# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MeMessengerUi/memessenger_login.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1280, 720)
        MainWindow.setStyleSheet("")
        MainWindow.setLocale(QtCore.QLocale(QtCore.QLocale.Russian, QtCore.QLocale.Russia))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.background = QtWidgets.QLabel(self.centralwidget)
        self.background.setGeometry(QtCore.QRect(0, 0, 1280, 720))
        self.background.setText("")
        self.background.setPixmap(QtGui.QPixmap("data/new_user.png"))
        self.background.setObjectName("background")
        self.label_1 = QtWidgets.QLabel(self.centralwidget)
        self.label_1.setGeometry(QtCore.QRect(830, 90, 481, 61))
        font = QtGui.QFont()
        font.setFamily("Nunito Black")
        font.setPointSize(16)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setKerning(True)
        font.setStyleStrategy(QtGui.QFont.PreferDefault)
        self.label_1.setFont(font)
        self.label_1.setStyleSheet("")
        self.label_1.setObjectName("label_1")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(830, 150, 301, 41))
        font = QtGui.QFont()
        font.setFamily("Nunito Black")
        font.setPointSize(13)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(990, 200, 211, 31))
        font = QtGui.QFont()
        font.setFamily("Nunito Black")
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.email = QtWidgets.QLineEdit(self.centralwidget)
        self.email.setGeometry(QtCore.QRect(900, 270, 290, 50))
        font = QtGui.QFont()
        font.setFamily("Nunito")
        font.setPointSize(14)
        self.email.setFont(font)
        self.email.setStyleSheet("border-radius: 10px")
        self.email.setObjectName("email")
        self.password = QtWidgets.QLineEdit(self.centralwidget)
        self.password.setGeometry(QtCore.QRect(900, 360, 290, 50))
        font = QtGui.QFont()
        font.setFamily("Nunito")
        font.setPointSize(14)
        self.password.setFont(font)
        self.password.setStyleSheet("border-radius: 10px")
        self.password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password.setObjectName("password")
        self.create = QtWidgets.QPushButton(self.centralwidget)
        self.create.setGeometry(QtCore.QRect(940, 490, 201, 61))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(-1)
        font.setUnderline(False)
        font.setStrikeOut(False)
        self.create.setFont(font)
        self.create.setStyleSheet("QPushButton {\n"
"  background-color: #FFFFFF;\n"
"    border: 1px solid #CCCCCC;\n"
"    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;\n"
"    transition: border 0.2s linear 0s, box-shadow 0.2s linear 0s;\n"
"        border-radius: 4px;\n"
"    color: #555555;\n"
"    display:block;\n"
"        width:120px;\n"
"        margin: 20px auto;\n"
"    font-size: 14px;\n"
"        text-align:center;\n"
"    height: 20px;\n"
"    line-height: 20px;\n"
"    margin-bottom: 10px;\n"
"    padding: 4px 6px;\n"
"    vertical-align: middle;\n"
"        text-decoration:none;\n"
"}\n"
"QPushButton:hover, QPushButton:focus {\n"
"   border-color: rgba(82, 168, 236, 0.8);\n"
"   box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);\n"
"   outline: 0 none;\n"
"}")
        self.create.setObjectName("create")
        self.rq_id = QtWidgets.QPushButton(self.centralwidget)
        self.rq_id.setGeometry(QtCore.QRect(910, 430, 221, 61))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(-1)
        font.setUnderline(False)
        font.setStrikeOut(False)
        self.rq_id.setFont(font)
        self.rq_id.setStyleSheet("QPushButton {\n"
"  background-color: #FFFFFF;\n"
"    border: 1px solid #CCCCCC;\n"
"    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;\n"
"    transition: border 0.2s linear 0s, box-shadow 0.2s linear 0s;\n"
"        border-radius: 4px;\n"
"    color: #555555;\n"
"    display:block;\n"
"        width:120px;\n"
"        margin: 20px auto;\n"
"    font-size: 14px;\n"
"        text-align:center;\n"
"    height: 20px;\n"
"    line-height: 20px;\n"
"    margin-bottom: 10px;\n"
"    padding: 4px 6px;\n"
"    vertical-align: middle;\n"
"        text-decoration:none;\n"
"}\n"
"QPushButton:hover, QPushButton:focus {\n"
"   border-color: rgba(82, 168, 236, 0.8);\n"
"   box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);\n"
"   outline: 0 none;\n"
"}")
        self.rq_id.setObjectName("rq_id")
        self.login = QtWidgets.QPushButton(self.centralwidget)
        self.login.setGeometry(QtCore.QRect(910, 550, 221, 61))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(-1)
        font.setUnderline(False)
        font.setStrikeOut(False)
        self.login.setFont(font)
        self.login.setStyleSheet("QPushButton {\n"
"  background-color: #FFFFFF;\n"
"    border: 1px solid #CCCCCC;\n"
"    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;\n"
"    transition: border 0.2s linear 0s, box-shadow 0.2s linear 0s;\n"
"        border-radius: 4px;\n"
"    color: #555555;\n"
"    display:block;\n"
"        width:120px;\n"
"        margin: 20px auto;\n"
"    font-size: 14px;\n"
"        text-align:center;\n"
"    height: 20px;\n"
"    line-height: 20px;\n"
"    margin-bottom: 10px;\n"
"    padding: 4px 6px;\n"
"    vertical-align: middle;\n"
"        text-decoration:none;\n"
"}\n"
"QPushButton:hover, QPushButton:focus {\n"
"   border-color: rgba(82, 168, 236, 0.8);\n"
"   box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);\n"
"   outline: 0 none;\n"
"}")
        self.login.setObjectName("login")
        self.error_email = QtWidgets.QLabel(self.centralwidget)
        self.error_email.setGeometry(QtCore.QRect(900, 320, 291, 20))
        font = QtGui.QFont()
        font.setItalic(True)
        self.error_email.setFont(font)
        self.error_email.setStyleSheet("color: red;")
        self.error_email.setText("")
        self.error_email.setObjectName("error_email")
        self.error_password = QtWidgets.QLabel(self.centralwidget)
        self.error_password.setGeometry(QtCore.QRect(900, 410, 291, 20))
        font = QtGui.QFont()
        font.setItalic(True)
        self.error_password.setFont(font)
        self.error_password.setStyleSheet("color: red;")
        self.error_password.setText("")
        self.error_password.setObjectName("error_password")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MeMessenger Login Alpha"))
        self.label_1.setText(_translate("MainWindow", "Добро пожаловать в MeMessenger"))
        self.label_2.setText(_translate("MainWindow", "Чтобы вы могли начать общаться, "))
        self.label_3.setText(_translate("MainWindow", "Создайте учетную запись"))
        self.email.setPlaceholderText(_translate("MainWindow", "Введите почту..."))
        self.password.setPlaceholderText(_translate("MainWindow", "Введите пароль..."))
        self.create.setText(_translate("MainWindow", "Создать"))
        self.rq_id.setText(_translate("MainWindow", "Войти через Rq ID"))
        self.login.setText(_translate("MainWindow", "Есть аккаунт?"))
