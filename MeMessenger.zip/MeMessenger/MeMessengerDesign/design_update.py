# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MeMessengerUi/memessenger_update.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(400, 600)
        MainWindow.setStyleSheet("background-color: #305459")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(30, 40, 340, 70))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(25)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.info = QtWidgets.QLabel(self.centralwidget)
        self.info.setGeometry(QtCore.QRect(20, 490, 361, 61))
        font = QtGui.QFont()
        font.setFamily("Nunito")
        font.setPointSize(20)
        self.info.setFont(font)
        self.info.setStyleSheet("color: #fff")
        self.info.setAlignment(QtCore.Qt.AlignCenter)
        self.info.setObjectName("info")
        self.status = QtWidgets.QLabel(self.centralwidget)
        self.status.setGeometry(QtCore.QRect(20, 430, 361, 41))
        font = QtGui.QFont()
        font.setFamily("Nunito")
        font.setPointSize(18)
        self.status.setFont(font)
        self.status.setStyleSheet("color: #fff")
        self.status.setAlignment(QtCore.Qt.AlignCenter)
        self.status.setObjectName("status")
        self.gif = QtWidgets.QLabel(self.centralwidget)
        self.gif.setGeometry(QtCore.QRect(10, 120, 380, 290))
        self.gif.setText("")
        self.gif.setScaledContents(False)
        self.gif.setAlignment(QtCore.Qt.AlignCenter)
        self.gif.setObjectName("gif")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "MeMessenger"))
        self.info.setText(_translate("MainWindow", "Checking update..."))
        self.status.setText(_translate("MainWindow", "Status"))
