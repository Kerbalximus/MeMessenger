#from main import UpdateMeMessenger
from MeMessengerWindows.MeMessengerApp import MeMessengerApp
import sys
from PyQt5 import QtWidgets
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QListWidgetItem, QWidget, QApplication, QLabel
from PyQt5.QtGui import QMovie
from mongo.mongo_controller import MongoController as mongo
import json
from datetime import datetime
from pymongo import MongoClient

from MeMessengerDesign import design_welcome

#69d2ff

class WelcomeMeMessenger(QtWidgets.QMainWindow, design_welcome.Ui_MainWindow):
    def __init__(self, user_id, token, name, email, password):
        super().__init__()
        self.setupUi(self)
        self.gif = QMovie("./data/birthday.gif")
        self.background.setMovie(self.gif)
        self.gif.start()

        self.coll_chats = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").personal_chat.chat
        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users


        self.all_month = {"Январь": 1, "Февраль": 2, "Март": 3, "Апрель": 4, "Май": 5, "Июнь": 6, "Июль": 7, "Август": 8, "Сентябрь": 9, "Октябрь": 10, "Ноябрь": 11, "Декабрь": 12}

        self.init_list_widget()
        
        self.user_id = user_id
        self.token = token
        self.name = name
        self.email = email
        self.password = password

        self.day_button.clicked.connect(self.show_day_list_widget)
        self.month_button.clicked.connect(self.show_month_list_widget)
        self.year_button.clicked.connect(self.show_year_list_widget)
        self.next_button.clicked.connect(self.start_window)

        self.day_list_widget.itemActivated.connect(self.day_list_widget_select)
        self.month_list_widget.itemActivated.connect(self.month_list_widget_select)
        self.year_list_widget.itemActivated.connect(self.year_list_widget_select)
        

        self.next_button.setEnabled(False)
        self.next_button.setStyleSheet("background-color: #69d2ff; border-radius: 10px; color: #fff")
        self.setDay = False
        self.setMonth = False
        self.setYear = False

    def start_window(self):
        day = int(self.day_button.text())
        month = int(str(self.all_month[self.month_button.text()]))
        year = int(self.year_button.text())
        date = datetime(year, month, day, 0, 0, 0, 0)
        print(date)
        
        self.coll_users.insert_one(
            {
                "name": str(self.name),
                "email": str(self.email),
                "password": str(self.password),
                "id": str(self.user_id),
                "token": str(self.token),
                "friends": [],
                "friends_requests": [],
                "birthday": date,
                "created_date": datetime.utcnow() 
            }
        )

        data = {
            "id": self.user_id,
            "token": self.token,
            "password": self.password
        }

        with open("login.json", "w") as login:
            json.dump(data, login)


        #  "create_date": datetime.utcnow()
        self.hide()
        self.window = MeMessengerApp(data['token'])
        self.window.show()
        

    def check_select(self):
        if self.setDay and self.setMonth and self.setYear:
            self.next_button.setEnabled(True)
            self.next_button.setStyleSheet("background-color: #2ba3d6;\nborder-radius: 10px;\ncolor: #fff;")

            
            

    def init_list_widget(self):
        self.day_list_widget.hide()
        self.month_list_widget.hide()
        self.year_list_widget.hide()

        for day in range(1, 32):
            self.day_list_widget.addItem(str(day))

        for month in self.all_month:
            self.month_list_widget.addItem(str(month))

        for year in range(1900, 2021):
            self.year_list_widget.addItem(str(year))

    def day_list_widget_select(self, event):
        
        self.day_button.setText(event.text())
        self.setDay = True
        self.check_select()

    def month_list_widget_select(self, event):
        
        self.month_button.setText(event.text())
        self.setMonth = True
        self.check_select()

    def year_list_widget_select(self, event):
        
        self.year_button.setText(event.text())
        self.setYear = True
        self.check_select()


    def show_day_list_widget(self):
        self.month_list_widget.hide()
        self.year_list_widget.hide()
        if self.day_list_widget.isHidden():
            self.day_list_widget.show()
        else:
            self.day_list_widget.hide()

    def show_month_list_widget(self):
        self.day_list_widget.hide()
        self.year_list_widget.hide()
        if self.month_list_widget.isHidden():
            self.month_list_widget.show()
            
        else:
            self.month_list_widget.hide()
            

    def show_year_list_widget(self):
        self.day_list_widget.hide()
        self.month_list_widget.hide()
        if self.year_list_widget.isHidden():
            self.year_list_widget.show()
        else:
            self.year_list_widget.hide()


# pyuic5 MeMessengerUi/memessenger_welcome.ui -o MeMessengerDesign/design_welcome.py