from PyQt5.QtCore import QTimer
from events.OnNewFriend import OnNewFriend
import sys
from threading import Thread
import time
from PyQt5 import QtWidgets
from pymongo import MongoClient
from events import OnMessageEvent
import hashlib
from datetime import datetime
import pytz
from widgets.widgets import Widgets
from MeMessengerDesign import design
from datetime import datetime
from MeMessengerWindows.SettingMeMessenger import SettingMeMessenger
from events.LoadMessage import LoadMessage
from PyQt5.QtGui import QMovie
import os
import platform
#import win10toast

class MeMessengerApp(QtWidgets.QMainWindow, design.Ui_MainWindow):
    def __init__(self, token):
        # Это здесь нужно для доступа к переменным, методам
        # и т.д. в файле design.py
        super().__init__()
        self.setupUi(self)  # Это нужно для инициализации нашего дизайна
        self.coll_chats = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.personal_chats
        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users
        
        
        self.active_recipient = None

        self.user_data = self.coll_users.find_one({"token": token})
        self.user_id = self.user_data['id']
        self.isHide = False
        self.chat_id = "123"

        self.OnMessageEvent_thread = None

        self.on_new_friend_init()

        self.thread_message = OnMessageEvent.MessageEvent(self.chat_id, self, self.message_list)
        self.thread_message.dataChanged.connect(self.new_message)
        self.thread_message.start()

        self.chats_list.itemActivated.connect(self.selected_option_chatlist_event)
        self.find_friend_line.returnPressed.connect(self.find_friend)
        self.setting_button.clicked.connect(self.show_setting)
        #self.chats_list.addItem("Hi")
        #self.chats_list.addItem("text")

        self.select_user_info()
        self.SetPersonalChat()

        self.tray_init()

        self.load_message_gif = QMovie("./data/loading1.gif")
        self.load_message.setMovie(self.load_message_gif)
        self.load_message_gif.start()


        self.text_message.returnPressed.connect(self.send_button_def)
        self.send_message_button.clicked.connect(self.send_button_def)

        print("hi")
        #self.search_button.clicked.connect(self.search_user)

    # def setting_file(self):
    #     if os.path.isfile("setting.")

    def on_new_friend_init(self):
        self.on_new_friend_thread = OnNewFriend(self)
        self.on_new_friend_thread.new_friend.connect(self.SetPersonalChat)
        self.on_new_friend_thread.start()

    def tray_init(self):
        self.tray_icon = QtWidgets.QSystemTrayIcon(self)
        self.tray_icon.setIcon(self.style().standardIcon(QtWidgets.QStyle.SP_ComputerIcon))
 
        '''
            Объявим и добавим действия для работы с иконкой системного трея
            show - показать окно
            hide - скрыть окно
            exit - выход из программы
        '''
        show_action = QtWidgets.QAction("Show", self)
        hide_action = QtWidgets.QAction("Hide", self)
        show_action.triggered.connect(self.show)
        hide_action.triggered.connect(self.hide)
        tray_menu = QtWidgets.QMenu()
        tray_menu.addAction(show_action)
        tray_menu.addAction(hide_action)
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.show()

    def show_setting(self):

        self.window = SettingMeMessenger(self.user_id)
        self.window.show()

    def new_friend_event(self, friend):

        print("friend_event")

        friend_user = friend

        item = QtWidgets.QListWidgetItem(friend_user['id'])
                
        # create widget
        
        widget = QtWidgets.QWidget()
        widget.resize(200, 50)
        widgetText = QtWidgets.QLabel(friend_user['name'])

        widgetLayout = QtWidgets.QHBoxLayout()
        widgetLayout.addWidget(widgetText)
            
        widgetLayout.addStretch()

        widget.setStyleSheet("border-radius: 10px; background-color: #305459; color: #fff")
        widget.setLayout(widgetLayout)
        item.setSizeHint(widget.sizeHint())  
        


        self.chats_list.addItem(item)
        self.chats_list.setItemWidget(item, widget)

        self.coll_chats.insert(
                {
                    "recipient": [self.user_id, friend_user['id']],
                    "messages": [],
                    "id": hashlib.sha256(f"{sorted([self.user_id, self.active_recipient['id']])}".encode()).hexdigest()
                }
            )

    def get_user(self, id):
        return self.coll_users.find_one({"id": id})

    def send_button_def(self):
        text = self.text_message.text()

        if not text.strip():
            return

        if not self.coll_chats.find_one({"id": hashlib.sha256(f"{sorted([self.user_id, self.active_recipient['id']])}".encode()).hexdigest()}):
            self.coll_chats.insert(
                {
                    "recipient": sorted([self.user_id, self.active_recipient['id']]),
                    "messages": [],
                    "id": hashlib.sha256(f"{sorted([self.user_id, self.active_recipient['id']])}".encode()).hexdigest()
                }
            )

        self.load_message.hide()

        self.chat_id = hashlib.sha256(f"{sorted([self.user_id, self.active_recipient['id']])}".encode()).hexdigest()

        
        
        chat = self.coll_chats.find_one({"id": hashlib.sha256(f"{sorted([self.user_id, self.active_recipient['id']])}".encode()).hexdigest()})
        chat['messages'].append(
            {
            "author": self.user_id,
            "text": text,
            "datetime": datetime.utcnow(),
            "id": hashlib.sha256(f"{self.user_id}{text}{datetime.utcnow()}".encode()).hexdigest()
        }
        )
        self.coll_chats.save(chat)

        # print(text)
        self.text_message.setText('')

        




    def find_friend(self):
        friend_name = self.find_friend_line.text()
        friend = self.coll_users.find_one({"name": friend_name})

        if not friend:
            friend = self.coll_users.find_one({"email": friend_name})

        if not friend:
            result  = QtWidgets.QMessageBox.question(
                self, "Нам немного неловко...","Не удалось найти данный аккаунт",
                QtWidgets.QMessageBox.Ok
            )
            if result == QtWidgets.QMessageBox.Ok:
                return 0

        if self.user_id in friend['friends'] or self.user_id in friend['friends_requests']:
            result = QtWidgets.QMessageBox.question(
                self, "Стойте", "Вы уже отправили запрос дружбу данному человек или вы уже друзья",
                QtWidgets.QMessageBox.Ok
            )

            if result == QtWidgets.QMessageBox.Ok:
                return 0

        print(self.user_data, friend_name)
        

        user = self.coll_users.find_one({"id": self.user_id})
        friend['friends_requests'].append(self.user_id)

        if friend['id'] in user['friends_requests']:
            user['friends_requests'].remove(friend['id'])
            friend['friends_requests'].remove(self.user_id)
            user['friends'].append(friend['id'])
            friend['friends'].append(self.user_id)

            self.coll_users.save(user)
            self.coll_users.save(friend)

            self.new_friend_event(friend)
            return
        self.coll_users.save(user)
        self.coll_users.save(friend)
        


    def SetPersonalChat(self):
        for user in self.coll_users.find_one({"id": self.user_id})['friends']:

            friend_user = self.coll_users.find_one({"id": user})

            item = QtWidgets.QListWidgetItem(friend_user['id'])
                    
            # create widget
            
            widget = QtWidgets.QWidget()
            widget.resize(200, 50)
            widgetText = QtWidgets.QLabel(friend_user['name'])

            widgetLayout = QtWidgets.QHBoxLayout()
            widgetLayout.addWidget(widgetText)
                
            widgetLayout.addStretch()

            widget.setStyleSheet("border-radius: 10px; background-color: #305459; color: #fff")
            widget.setLayout(widgetLayout)
            item.setSizeHint(widget.sizeHint())  
            


            self.chats_list.addItem(item)
            self.chats_list.setItemWidget(item, widget)
        

    def selected_option_chatlist_event(self, event):

        self.message_list.clear()


        recipient_user = self.coll_users.find_one({"id": event.text()})

        if recipient_user == self.active_recipient:
            return

        self.active_recipient = recipient_user
        print(self.active_recipient)

        chat_info = self.coll_chats.find_one({"id": hashlib.sha256(f"{sorted([self.user_id, self.active_recipient['id']])}".encode()).hexdigest()})
        print(chat_info)
        self.text_message.setPlaceholderText(f"Написать @{recipient_user['name']}")

        if not chat_info:
            return

        self.chat_id = hashlib.sha256(f"{sorted([self.user_id, self.active_recipient['id']])}".encode()).hexdigest()

        # for data in chat_info['messages']:

        #     widget = Widgets.message_widget(data, self.get_user(data['author']))

        #     item = QtWidgets.QListWidgetItem()
        #     item.setSizeHint(widget.sizeHint())

        #     self.message_list.addItem(item)
        #     self.message_list.setItemWidget(item, widget)

        self.chat_info = chat_info

        self.load_message.show()

        # try:
        #     self.thread_message.terminate()
        #     print("here i am")

        # except AttributeError:
        #     pass

        # print(self.message_list.item(1).text())

        self.thread_load_message = LoadMessage(chat_info, self)
        self.thread_load_message.finish.connect(self.on_message_event)
        self.thread_load_message.dataMessage.connect(self.message)
        self.thread_load_message.start()

        


    def on_message_event(self, event):

        # print(self.message_list.item(self.message_list.count()-1).text())

        # self.load_message_gif.stop()
        self.load_message.hide()

        # self.thread_message = OnMessageEvent.MessageEvent(self.chat_info['id'], self, self.message_list)
        # self.thread_message.dataChanged.connect(self.new_message)
        # self.thread_message.start()
        
    def push(self, title, message):
        plt = platform.system()
        if plt == "Darwin":
            command = '''
            osascript -e 'display notification "{message}" with title "{title}"'
            '''
        elif plt == "Linux":
            command = f'''
            notify-send "{title}" "{message}"
            '''
        #elif plt == "Windows":
        #   win10toast.ToastNotifier().show_toast(title, message)
        #  return
        else:
            return
        os.system(command)

    def message(self, data):
        widget = Widgets.message_widget(data, self.get_user(data['author']))

        item = QtWidgets.QListWidgetItem(data['id'])
        item.setSizeHint(widget.sizeHint())

        self.message_list.addItem(item)
        self.message_list.setItemWidget(item, widget)


    def new_message(self, message):

        widget = Widgets.message_widget(message, self.get_user(message['author']))

        item = QtWidgets.QListWidgetItem()
        item.setSizeHint(widget.sizeHint())

        self.message_list.addItem(item)
        self.message_list.setItemWidget(item, widget)

        self.online_time = datetime.now(pytz.timezone("gmt"))
        if self.user_id != message['author']:
            self.push("MeMessenger", f"{self.get_user(message['author'])['name']}:{message['text']}")
            

    def select_user_info(self):
        user_data = self.coll_users.find_one({"id": self.user_id})
        self.user_name.setText(user_data['name'])
        self.user_email.setText(user_data['email'])


    def closeEvent(self, event):
        result = QtWidgets.QMessageBox.question(
            self, 'Стойте!', 'Вы точно хотите закрыть MeMessenger?',
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        if result == QtWidgets.QMessageBox.Yes:
            event.accept()
            
            sys.exit()
        else:
            event.ignore()