import os
import sys
import time
from MeMessengerWindows import LogInMeMessenger
from PyQt5 import QtWidgets
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QWidget, QApplication, QLabel
from PyQt5.QtGui import QMovie

from MeMessengerWindows.MeMessengerApp import MeMessengerApp
from MeMessengerDesign import design_update
from pymongo import MongoClient

class UpdateMeMessenger(QtWidgets.QMainWindow, design_update.Ui_MainWindow):
    def __init__(self, data, app):
        super().__init__()
        self.setupUi(self)

        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users

        self.data = data
        self.check_id = True
        self.check_password = True
        self.check_token = True
        self.app = app

        self.update_gif = QMovie("data/loading1.gif")
        self.gif.setMovie(self.update_gif)
        self.update_gif.start()

        # self.timer = QTimer()
        # self.timer.timeout.connect(self.timer_stop)
        # self.timer.start(1000)

        print("lol")

        time.sleep(5)

        print("LOOOL")


        

        if not self.coll_users.find_one({"id": data['id']}):
            self.info.setText("")
            self.status.setText("Неверные данные авторизации")
            self.check_id = False
            print("check id")
            self.window = LogInMeMessenger.LogInMeMessenger()
            self.window.show()
            self.app.exec_()



        user_data = self.coll_users.find_one({"id": data['id']})

        
        
        if user_data['token'] != data['token']:
            self.info.setText("")
            self.status.setText("Неверные данные авторизации")
            self.check_token = False
            print("check token")
        
        if self.check_id and self.check_password and self.check_token:
            self.info.setText("")
            self.status.setText("Запуск")

            # self.app.exec_()
            self.window = MeMessengerApp(self.data['token'])
            #self.hide()
            self.window.show()
            self.app.exec_()

        

        # os.execl("main.py")


    def timer_stop(self):
        self.timer.stop()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UpdateMeMessenger()
    window.show()
    sys.exit(app.exec_())

