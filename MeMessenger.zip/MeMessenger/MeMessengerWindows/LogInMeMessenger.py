import sys
from PyQt5 import QtWidgets
from PyQt5.QtCore import QPoint, QPropertyAnimation, QTimer
from pymongo import MongoClient
from validate_email import validate_email
import json
import os
from hashlib import sha256, sha384, sha512
from MeMessengerWindows.LoadMeMessenger import LoadMeMessenger
from MeMessengerWindows.MeMessengerApp import MeMessengerApp
from MeMessengerDesign import design_login
from MeMessengerWindows.WelcomeMeMessenger import WelcomeMeMessenger
from mongo.mongo_controller import MongoController as mongo


class LogInMeMessenger(QtWidgets.QMainWindow, design_login.Ui_MainWindow):
    def __init__(self):

        super().__init__()
        self.setupUi(self)
        self.coll_messages = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").personal_chats.chat
        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users
                

        self.login.clicked.connect(self.login_account)
        self.rq_id.clicked.connect(self.session_login)
        self.create.clicked.connect(self.create_account)

        # if not os.path.isfile("login.json"):
        #     with open("login.json", "w") as login:
        #         login.write("Нет сессии")

    

    def create_account(self):

        self.text_email = self.email.text()
        self.text_password = self.password.text()
        self.text_name = self.text_email

        if not self.text_email.strip():
            self.error_email.setText("Введите почту")
            return

        if not self.text_password.strip():
            self.error_password.setText("Введите пароль")
            return

        if self.coll_users.find_one({"email": self.text_email}):
            self.error_email.setText("Почта занята")
            return 

        self.text_password = sha256(self.text_password.encode()).hexdigest()
        self.user_id = sha384(f"{self.text_name}{self.text_email}".encode()).hexdigest()
        self.token = sha512(f"{self.text_name}{self.text_email}{self.text_password}{self.user_id}".encode()).hexdigest()

        

        

        self.animation_label = QtWidgets.QLabel(self)
        self.animation_label.setStyleSheet("""
                                            background-color: #d7d7ff;
                                            color: #fff
                                        """)

        self.animation_label.resize(1280, 720)
        self.animation_label.move(-1280, 0)
        self.animation_label.show()
        

        animation = QPropertyAnimation(self.animation_label, b'pos', self)
        animation.setStartValue(QPoint(-1280, 0))
        animation.setEndValue(QPoint(0, 0))

        animation.setDuration(500)

        animation.start()

        self.timer = QTimer()
        self.timer.timeout.connect(self.show_welcome_window)
        self.timer.start(500)

    def show_welcome_window(self):
        self.hide()
        self.window = WelcomeMeMessenger(self.user_id, self.token, self.text_name, self.text_email, self.text_password)
        self.window.show()
        self.timer.stop()


    def show_main_window(self, id):

        user_data = self.coll_users.find_one({"id": id})

        login_json = {
            "email": user_data['email'],
            "name": user_data['name'],
            "token": user_data['token'],
            "id": user_data['id']
        }

        with open("login.json", "w") as login:
            json.dump(login_json, login)
        
        self.hide()
        self.window = LoadMeMessenger()
        self.window.show()


        self.window = MeMessengerApp(id)
        self.hide()
        self.window.show()

    def login_account(self):
        email = self.email.text()
        password = self.password.text()

        if not email.strip():
            self.error_email.setText("Введите почту")
            return

        if not password.strip():
            self.error_password.setText("Введите пароль")
            return

        if not self.coll_users.find_one({"email": email}):
            self.error_email.setText("Аккаунта с такой почтой не существует")
            return

        user_data = self.coll_users.find_one({"email": email})
        
        if user_data['password'] != sha256(password.encode()).hexdigest():
            self.error_password.setText("Неверный пароль")
            return

        data = {
            "id": user_data['id'],
            "token": user_data['token'],
            "password": user_data['password']
        }

        with open("login.json", "w") as login:
            json.dump(data, login)

        self.hide()
        self.window = MeMessengerApp(user_data['token'])
        self.window.show()

        


    def session_login(self):
        with open("login.json") as login:
            login_list = json.load(login)

        self.show_main_window(login_list['id'])

    def closeEvent(self, event):
        result = QtWidgets.QMessageBox.question(
            self, 'Стойте', 'Вы точно хотите закрыть MeMessenger?',
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        if result == QtWidgets.QMessageBox.Yes:
            event.accept()
            sys.exit()
        else:
            event.ignore() 