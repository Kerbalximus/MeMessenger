from MeMessengerDesign import design_setting
from PyQt5 import QtWidgets, QtCore
from widgets.widgets import Widgets
import os
import sys

class SettingMeMessenger(QtWidgets.QMainWindow, design_setting.Ui_MainWindow):
    def __init__(self, id):
        super().__init__()
        self.setupUi(self)
        print("Hi")

        self.setting_button.clicked.connect(self.close_window)

        self.fill_list()

    def set_item(self, item, widget):
        self.setting_list.addItem(item)
        self.setting_list.setItemWidget(item, widget)

    def log_out(self):
        os.remove("login.json")
        sys.exit()

    def fill_list(self):
        # self.setting_list.setDisabled(True)
        item, widget = Widgets.label_widget("Логирование", 16)
        self.set_item(item, widget)

        item, widget = Widgets.label_widget("Данный параметр указывает, необходимо ли собирать и сохранять все данные программы и сохранять их в файл или нет")
        self.set_item(item, widget)

        item, widget, switch = Widgets.switch_widget()
        self.set_item(item, widget)

        item, widget = Widgets.label_widget("Режим автономности", 16)
        self.set_item(item, widget)

        item, widget = Widgets.label_widget("Подробнее: https://telegra.ph/Rezhim-avtonomnosti-08-21")
        self.set_item(item, widget)

        item, widget, switch = Widgets.switch_widget()
        widget.setDisabled(True)
        switch.setChecked(True)
        self.set_item(item, widget)

        item, widget = Widgets.label_widget("Выход", 16)
        self.set_item(item, widget)

        item, widget = Widgets.label_widget("Приложение закроется, а при повторном запуске вам надо будет заново войти в аккаунт")
        self.set_item(item, widget)

        item, widget, button = Widgets.button_widget("Выйти")
        self.set_item(item, widget)

        button.clicked.connect(self.log_out)
        

    def close_window(self):
        self.hide()