from PyQt5 import QtWidgets

from MeMessengerDesign import design_load
                
class LoadMeMessenger(QtWidgets.QMainWindow, design_load.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
