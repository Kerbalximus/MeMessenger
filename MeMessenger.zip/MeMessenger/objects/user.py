class User():
    """
    Объект пользователя
    Получить можно из "id", "token", "email"

    Attributes:
    "name" - возращает имя пользователя
    "email" - возращает почту пользователя
    ""
    """
    def __init__(self, id) -> None:
        self.id = id