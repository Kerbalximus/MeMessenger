import sys
from PyQt5 import QtCore, QtWidgets, QtGui
from PyQt5.QtWidgets import QApplication, QWidget, QDesktopWidget, QMainWindow, QAction, qApp
from PyQt5.QtGui import QIcon

HEIGHT = 750
WIDTH = 1300

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.resize(128, 128)

        self.label = QtWidgets.QLabel()
        self.label.setStyleSheet("""

        
        border-image: url(MeMessengerUi/image.png);
        border-radius: 64px;
        """)

        self.label.resize(128, 128)

        self.label.show()



if __name__ == '__main__':
    app = QApplication(sys.argv)

#     styleFile="styles/styles.qss"
# #    styleFile="D:/_Qt/Python-Examples/_PyQt5/Style/style.css"
#     with open(styleFile,"r") as sf:
#         app.setStyleSheet(sf.read())

    mainWindow = MainWindow()
    sys.exit(app.exec_())