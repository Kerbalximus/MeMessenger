from pymongo import MongoClient
from hashlib import sha256, sha512

class MongoController():
    def __init__(self) -> None:
        self.cluster = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
        self.users = self.cluster['data']['user']
        self.chats = self.cluster['data']['chat']

    def users_mongo(self):
        return self.users

    def chats_mongo(self):
        return self.chats

    def cluster_mongo(self):
        return self.cluster

    def users_insert(self, data):
        self.users_mongo.insert(data)

    def get_user(self, data):
        user = self.users.find_one(data)

        return user

   
    def get_channel(self, id):
        chat = self.chats_mongo.find_one({"id": id})
        return chat