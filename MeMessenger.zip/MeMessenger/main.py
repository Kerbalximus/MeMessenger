from MeMessengerWindows.MeMessengerApp import MeMessengerApp
from MeMessengerWindows.UpdateMeMessenger import UpdateMeMessenger
import sys
from PyQt5 import QtWidgets
import json
import os

from MeMessengerWindows.LogInMeMessenger import LogInMeMessenger

from pymongo import MongoClient


def main():
    
    app = QtWidgets.QApplication([])
    
    app.setStyle("QtCurve")
    

    if os.path.isfile("login.json"):
        with open("login.json") as login:
            data = json.load(login)


        
        
        window = UpdateMeMessenger(data, app)
        window.show()
        app.exec_()
        sys.exit(app.exec_())
    else:
        window = LogInMeMessenger()

        window.show()
        app.exec_()
        sys.exit(app.exec_())


if __name__ == '__main__':
    main()

    