from PyQt5 import QtCore, QtGui, QtWidgets

class Widgets():
    """
    Class for create/editing simple MeMeseenger's widgets
    """

    def __init__() -> None:
        pass

    def message_widget(message_data, author):

        # widget = QtWidgets.QWidget()
        # widget.resize(750, 60)
        # # widget.setStyleSheet("background-color: #bcdee8; border-radius: 15px")
        # name = QtWidgets.QLabel(author['name'])
        # name.resize(240, 20)
        # name.move(20, 0)
        # time = QtWidgets.QLabel(f"{str(message_data['datetime'].hour).zfill(2)}:{str(message_data['datetime'].minute).zfill(2)}")
        # time.resize(50, 15)
        # text = QtWidgets.QLabel(message_data['text'])
        # text.setWordWrap(True)
        # text.resize(750, 20)
        # text.move(30, 0)

        widget = QtWidgets.QWidget()
        widget.resize(750, 60)
        author_ = QtWidgets.QLabel(widget)
        author_.setText(f"{author['name']}  {str(message_data['datetime'].hour).zfill(2)}:{str(message_data['datetime'].minute).zfill(2)}")
        text = QtWidgets.QLabel(message_data['id'])
        text.move(30, 0)
        text.setText(message_data['text'])
        text.setWordWrap(True)
        

        widgetLayout = QtWidgets.QVBoxLayout()
        widgetLayout.addWidget(author_)
        # widgetLayout.addWidget(time)
        widgetLayout.addWidget(text)
        widgetLayout.addStretch()
        
        widget.setLayout(widgetLayout)
        
        return widget

    def switch_widget(data = ""):

        item = QtWidgets.QListWidgetItem(data)

        widget = QtWidgets.QWidget()
        widget.resize(64, 1100)

        switch = QtWidgets.QCheckBox()
        switch.setStyleSheet('''
            QCheckBox::indicator:unchecked {
                image: url(data/switch_off.png);
            }
            QCheckBox::indicator:checked {
                image: url(data/switch_on.png);
            }
        ''')

        widgetLayout = QtWidgets.QHBoxLayout()
        widgetLayout.addWidget(switch)

        widgetLayout.addStretch()
        widget.setLayout(widgetLayout)
        
        item.setSizeHint(widget.sizeHint())

        return item, widget, switch

    def label_widget(text: str, font_size = 13):

        item = QtWidgets.QListWidgetItem(text)

        widget = QtWidgets.QWidget()
        widget.resize(font_size * 2, 1100)

        label = QtWidgets.QLabel()
        label.setText(text)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(font_size)
        label.setFont(font)

        widgetLayout = QtWidgets.QHBoxLayout()
        widgetLayout.addWidget(label)

        widgetLayout.addStretch()
        widget.setLayout(widgetLayout)

        item.setSizeHint(widget.sizeHint())

        return item, widget

    def button_widget(text: str):

        item = QtWidgets.QListWidgetItem()

        widget = QtWidgets.QWidget()
        widget.resize(26, 100)

        button = QtWidgets.QPushButton()
        button.setText(text)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(13)
        button.setFont(font)
        button.setStyleSheet("QPushButton {\n"
        "  background-color: #FFFFFF;\n"
        "    border: 1px solid #CCCCCC;\n"
        "    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;\n"
        "    transition: border 0.2s linear 0s, box-shadow 0.2s linear 0s;\n"
        "        border-radius: 4px;\n"
        "    color: #555555;\n"
        "    display:block;\n"
        "        width:120px;\n"
        "        margin: 20px auto;\n"
        "    font-size: 14px;\n"
        "        text-align:center;\n"
        "    height: 20px;\n"
        "    line-height: 20px;\n"
        "    margin-bottom: 10px;\n"
        "    padding: 4px 6px;\n"
        "    vertical-align: middle;\n"
        "        text-decoration:none;\n"
        "}\n"
        "QPushButton:hover, QPushButton:focus {\n"
        "   border-color: rgba(82, 168, 236, 0.8);\n"
        "   box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);\n"
        "   outline: 0 none;\n"
        "}")

        widgetLayout = QtWidgets.QHBoxLayout()
        widgetLayout.addWidget(button)

        widgetLayout.addStretch()
        widget.setLayout(widgetLayout)

        item.setSizeHint(widget.sizeHint())

        return item, widget, button


