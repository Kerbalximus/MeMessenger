# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MeMessengerUi/status_widget.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(200, 50)
        self.name = QtWidgets.QLabel(Form)
        self.name.setGeometry(QtCore.QRect(0, 0, 200, 20))
        self.name.setObjectName("name")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(0, 20, 200, 20))
        self.label_2.setObjectName("label_2")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.name.setText(_translate("Form", "Никнейм"))
        self.label_2.setText(_translate("Form", "Статус"))
