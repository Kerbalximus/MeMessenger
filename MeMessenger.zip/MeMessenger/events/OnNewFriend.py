import time
from PyQt5 import QtWidgets
from PyQt5 import QtCore
from pymongo import MongoClient

class OnNewFriend(QtCore.QThread):
    new_friend = QtCore.pyqtSignal(bool)

    def __init__(self, window_self):
        super().__init__()
        self.setParent(window_self)
        self.window_self = window_self
        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users

        self.last_data = self.coll_users.find_one({"id": self.window_self.user_id})['friends']

    def run(self):

        while True:

            data = self.coll_users.find_one({"id": self.window_self.user_id})['friends']

            if self.last_data != data:
                self.window_self.chats_list.clear()
                self.new_friend.emit(True)
                self.last_data = data

            time.sleep(5)
