from widgets.widgets import Widgets
from PyQt5 import QtCore
from PyQt5.QtWidgets import *
from pymongo import MongoClient


class LoadMessage(QtCore.QThread):
    finish = QtCore.pyqtSignal(bool)
    dataMessage = QtCore.pyqtSignal(dict)

    def __init__(self, chat, window_self):
        super().__init__()
        self.coll = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.personal_chats
        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users

        self.chat = chat
        self.working = True
        self.window_self = window_self
        self.setParent(window_self)

        self.window_self.chats_list.itemActivated.connect(self.selected_option_chatlist_event)

    def selected_option_chatlist_event(self, event):
        self.working = False
        self.finish.emit(True)

    def get_user(self, id):

        return self.coll_users.find_one({"id": id})

    def run(self):

        for data in self.chat['messages']:

            self.dataMessage.emit(data)

        self.finish.emit(True)

    def stoped(self): 
        return self.working
