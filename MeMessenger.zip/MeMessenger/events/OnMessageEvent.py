from PyQt5 import QtCore
from PyQt5.QtWidgets import *
from pymongo import MongoClient
import threading
from datetime import datetime, timezone, tzinfo
import platform
#import win10toast
import time
import os
import pytz

from widgets.widgets import Widgets

class OnMessageEvent(threading.Thread):
    def __init__(self, window_self, chat_id):
        super().__init__()
        self.coll = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.personal_chats
        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users

        self.online_time = datetime.now(pytz.timezone("gmt"))
        self.isStop = False
        self.chat_id = chat_id
        self.window_self = window_self

        window_self.chats_list.itemActivated.connect(self.selected_option_chatlist_event)

    def selected_option_chatlist_event(self, event):
        self.isStop = True
        

     
    def push(self, title, message):
        plt = platform.system()
        if plt == "Darwin":
            command = '''
            osascript -e 'display notification "{message}" with title "{title}"'
            '''
        elif plt == "Linux":
            command = f'''
            notify-send "{title}" "{message}"
            '''
        #elif plt == "Windows":
        #   win10toast.ToastNotifier().show_toast(title, message)
        #  return
        else:
            return
        os.system(command)

    def get_user(self, id):
        user = self.coll_users.find_one({"id": id})
        return user
        


    def run(self):

        while not self.isStop:
            for message in self.coll.find_one({"id": self.chat_id})['messages']:
                if message['datetime'].replace(tzinfo=None) > self.online_time.replace(tzinfo=None):

                    widget = Widgets.message_widget(message, self.get_user(message['author']))

                    item = QListWidgetItem()
                    item.setSizeHint(widget.sizeHint())

                    self.window_self.message_list.addItem(item)
                    self.window_self.message_list.setItemWidget(item, widget)

                    self.online_time = datetime.now(pytz.timezone("gmt"))
                    if self.window_self.user_id != message['author']:
                        self.push("MeMessenger", f"{self.get_user(message['author'])['name']}:{message['text']}")
            time.sleep(0.5)
        return

class MessageEvent(QtCore.QThread):
    dataChanged = QtCore.pyqtSignal(dict)
    finished = QtCore.pyqtSignal(str)

    def __init__(self, chat_id, window_self, message_list): 
        super().__init__()
        self.working = True
        self.chat_id = chat_id
        self.setParent(window_self)
        self.coll = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.personal_chats
        self.coll_users = MongoClient("mongodb+srv://app:lTAdhqa94126r7EK@memessengercluster0.zjtea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority").data.users

        self.last_message = None

        self.online_time = datetime.utcnow()
        self.window_self = window_self
        self.message_list = message_list



    # def selected_option_chatlist_event(self, event):
    #     # self.working = False
    #     # self.wait()
    #     # print("ТАК")
    #     # self.terminate()
    #     # print("СЯК")
        

     
    def push(self, title, message):
        plt = platform.system()
        if plt == "Darwin":
            command = '''
            osascript -e 'display notification "{message}" with title "{title}"'
            '''
        elif plt == "Linux":
            command = f'''
            notify-send "{title}" "{message}"
            '''
        #elif plt == "Windows":
        #   win10toast.ToastNotifier().show_toast(title, message)
        #  return
        else:
            return
        os.system(command)

    def get_user(self, id):
        user = self.coll_users.find_one({"id": id})
        return user

    def run(self):

        while self.working:
            print(self.window_self.user_id)
            if self.coll.find_one({"id": self.window_self.chat_id}):
                for message in self.coll.find_one({"id": self.window_self.chat_id})['messages']:

                    if not self.working:
                        break

                    
                    if message['datetime'] > self.online_time:

                        # widget = Widgets.message_widget(message, self.get_user(message['author']))

                        # item = QListWidgetItem()
                        # item.setSizeHint(widget.sizeHint())

                        # self.window_self.message_list.addItem(item)
                        # self.window_self.message_list.setItemWidget(item, widget)

                        # self.dataChanged.emit(message)
                        # print(message['text'], self.working)

                        
                        # if self.message_list.item(self.message_list.count()-1).text() == message['id']:
                        #     pass
                        # else:
                        self.dataChanged.emit(message)
                        
                        

                        self.online_time = datetime.utcnow()
                        if self.window_self.user_id != message['author']:
                            self.push("MeMessenger", f"{self.get_user(message['author'])['name']}:{message['text']}")
            time.sleep(0.5)
        # print("КУ-КУ-КУ-КУ")
        return
    
    def stoped(self): 
        return self.working
            

        

# border-radius: 10px;\nborder: 8px solid #E3FEAA;background-color: #E3FEAA
    
                

